echo "Testing Steps file:";
python3 tests/steps_tester.py $1;