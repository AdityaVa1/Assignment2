echo "Testing Query:";
python3 tests/query_tester.py $1;
