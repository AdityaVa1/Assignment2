Select m.name, m.email
From members m, waitlist w,
Where w.member = m.email;
